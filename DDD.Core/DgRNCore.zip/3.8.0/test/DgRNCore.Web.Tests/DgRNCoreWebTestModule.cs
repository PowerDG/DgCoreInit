using Abp.AspNetCore.TestBase;
using Abp.Modules;
using Abp.Reflection.Extensions;
using DgRNCore.Web.Startup;
namespace DgRNCore.Web.Tests
{
    [DependsOn(
        typeof(DgRNCoreWebModule),
        typeof(AbpAspNetCoreTestBaseModule)
        )]
    public class DgRNCoreWebTestModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.UnitOfWork.IsTransactional = false; //EF Core InMemory DB does not support transactions.
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgRNCoreWebTestModule).GetAssembly());
        }
    }
}