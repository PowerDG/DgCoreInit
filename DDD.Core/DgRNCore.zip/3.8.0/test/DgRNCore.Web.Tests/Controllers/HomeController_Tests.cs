﻿using System.Threading.Tasks;
using DgRNCore.Web.Controllers;
using Shouldly;
using Xunit;

namespace DgRNCore.Web.Tests.Controllers
{
    public class HomeController_Tests: DgRNCoreWebTestBase
    {
        [Fact]
        public async Task Index_Test()
        {
            //Act
            var response = await GetResponseAsStringAsync(
                GetUrl<HomeController>(nameof(HomeController.Index))
            );

            //Assert
            response.ShouldNotBeNullOrEmpty();
        }
    }
}
