﻿using System;
using System.Threading.Tasks;
using Abp.TestBase;
using DgRNCore.EntityFrameworkCore;
using DgRNCore.Tests.TestDatas;

namespace DgRNCore.Tests
{
    public class DgRNCoreTestBase : AbpIntegratedTestBase<DgRNCoreTestModule>
    {
        public DgRNCoreTestBase()
        {
            UsingDbContext(context => new TestDataBuilder(context).Build());
        }

        protected virtual void UsingDbContext(Action<DgRNCoreDbContext> action)
        {
            using (var context = LocalIocManager.Resolve<DgRNCoreDbContext>())
            {
                action(context);
                context.SaveChanges();
            }
        }

        protected virtual T UsingDbContext<T>(Func<DgRNCoreDbContext, T> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<DgRNCoreDbContext>())
            {
                result = func(context);
                context.SaveChanges();
            }

            return result;
        }

        protected virtual async Task UsingDbContextAsync(Func<DgRNCoreDbContext, Task> action)
        {
            using (var context = LocalIocManager.Resolve<DgRNCoreDbContext>())
            {
                await action(context);
                await context.SaveChangesAsync(true);
            }
        }

        protected virtual async Task<T> UsingDbContextAsync<T>(Func<DgRNCoreDbContext, Task<T>> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<DgRNCoreDbContext>())
            {
                result = await func(context);
                context.SaveChanges();
            }

            return result;
        }
    }
}
