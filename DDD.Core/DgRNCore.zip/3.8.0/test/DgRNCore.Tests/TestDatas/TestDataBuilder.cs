using DgRNCore.EntityFrameworkCore;

namespace DgRNCore.Tests.TestDatas
{
    public class TestDataBuilder
    {
        private readonly DgRNCoreDbContext _context;

        public TestDataBuilder(DgRNCoreDbContext context)
        {
            _context = context;
        }

        public void Build()
        {
            //create test data here...
        }
    }
}