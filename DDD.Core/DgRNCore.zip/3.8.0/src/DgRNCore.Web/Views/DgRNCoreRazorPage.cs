﻿using Abp.AspNetCore.Mvc.Views;

namespace DgRNCore.Web.Views
{
    public abstract class DgRNCoreRazorPage<TModel> : AbpRazorPage<TModel>
    {
        protected DgRNCoreRazorPage()
        {
            LocalizationSourceName = DgRNCoreConsts.LocalizationSourceName;
        }
    }
}
