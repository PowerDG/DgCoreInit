﻿using Abp.AspNetCore;
using Abp.AspNetCore.Configuration;
using Abp.Modules;
using Abp.Reflection.Extensions;
using DgRNCore.Configuration;
using DgRNCore.EntityFrameworkCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace DgRNCore.Web.Startup
{
    [DependsOn(
        typeof(DgRNCoreApplicationModule), 
        typeof(DgRNCoreEntityFrameworkCoreModule), 
        typeof(AbpAspNetCoreModule))]
    public class DgRNCoreWebModule : AbpModule
    {
        private readonly IConfigurationRoot _appConfiguration;

        public DgRNCoreWebModule(IHostingEnvironment env)
        {
            _appConfiguration = AppConfigurations.Get(env.ContentRootPath, env.EnvironmentName);
        }

        public override void PreInitialize()
        {
            Configuration.DefaultNameOrConnectionString = _appConfiguration.GetConnectionString(DgRNCoreConsts.ConnectionStringName);

            Configuration.Navigation.Providers.Add<DgRNCoreNavigationProvider>();

            Configuration.Modules.AbpAspNetCore()
                .CreateControllersForAppServices(
                    typeof(DgRNCoreApplicationModule).GetAssembly()
                );
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgRNCoreWebModule).GetAssembly());
        }
    }
}