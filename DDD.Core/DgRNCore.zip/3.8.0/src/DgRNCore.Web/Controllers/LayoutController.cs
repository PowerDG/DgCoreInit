namespace DgRNCore.Web.Controllers
{
    public class LayoutController : DgRNCoreControllerBase
    {

    }
}