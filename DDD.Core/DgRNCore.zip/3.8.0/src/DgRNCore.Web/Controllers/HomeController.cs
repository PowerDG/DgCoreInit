using Microsoft.AspNetCore.Mvc;

namespace DgRNCore.Web.Controllers
{
    public class HomeController : DgRNCoreControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }
    }
}