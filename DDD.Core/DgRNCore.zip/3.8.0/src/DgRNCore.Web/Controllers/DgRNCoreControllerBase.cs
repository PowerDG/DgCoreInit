using Abp.AspNetCore.Mvc.Controllers;

namespace DgRNCore.Web.Controllers
{
    public abstract class DgRNCoreControllerBase: AbpController
    {
        protected DgRNCoreControllerBase()
        {
            LocalizationSourceName = DgRNCoreConsts.LocalizationSourceName;
        }
    }
}