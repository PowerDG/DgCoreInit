﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DgRNCore.Migrations
{
    public partial class Upgrade_ABP_380 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
