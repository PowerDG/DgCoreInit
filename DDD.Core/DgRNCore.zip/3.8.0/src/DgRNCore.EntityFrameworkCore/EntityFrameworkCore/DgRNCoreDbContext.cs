﻿using Abp.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace DgRNCore.EntityFrameworkCore
{
    public class DgRNCoreDbContext : AbpDbContext
    {
        //Add DbSet properties for your entities...

        public DgRNCoreDbContext(DbContextOptions<DgRNCoreDbContext> options) 
            : base(options)
        {

        }
    }
}
