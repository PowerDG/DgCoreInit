﻿using Abp.EntityFrameworkCore;
using Abp.Modules;
using Abp.Reflection.Extensions;

namespace DgRNCore.EntityFrameworkCore
{
    [DependsOn(
        typeof(DgRNCoreCoreModule), 
        typeof(AbpEntityFrameworkCoreModule))]
    public class DgRNCoreEntityFrameworkCoreModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgRNCoreEntityFrameworkCoreModule).GetAssembly());
        }
    }
}