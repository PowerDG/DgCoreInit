﻿using Abp.Application.Services;

namespace DgRNCore
{
    /// <summary>
    /// Derive your application services from this class.
    /// </summary>
    public abstract class DgRNCoreAppServiceBase : ApplicationService
    {
        protected DgRNCoreAppServiceBase()
        {
            LocalizationSourceName = DgRNCoreConsts.LocalizationSourceName;
        }
    }
}