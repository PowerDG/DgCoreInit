﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;

namespace DgRNCore
{
    [DependsOn(
        typeof(DgRNCoreCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class DgRNCoreApplicationModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgRNCoreApplicationModule).GetAssembly());
        }
    }
}