﻿using Abp.Modules;
using Abp.Reflection.Extensions;
using DgRNCore.Localization;

namespace DgRNCore
{
    public class DgRNCoreCoreModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Auditing.IsEnabledForAnonymousUsers = true;

            DgRNCoreLocalizationConfigurer.Configure(Configuration.Localization);
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgRNCoreCoreModule).GetAssembly());
        }
    }
}