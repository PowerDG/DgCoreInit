﻿namespace DgRNCore
{
    public class DgRNCoreConsts
    {
        public const string LocalizationSourceName = "DgRNCore";

        public const string ConnectionStringName = "Default";
    }
}