﻿using DgVCore.Configuration;
using DgVCore.Web;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace DgVCore.EntityFrameworkCore
{
    /* This class is needed to run EF Core PMC commands. Not used anywhere else */
    public class DgVCoreDbContextFactory : IDesignTimeDbContextFactory<DgVCoreDbContext>
    {
        public DgVCoreDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<DgVCoreDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            DbContextOptionsConfigurer.Configure(
                builder,
                configuration.GetConnectionString(DgVCoreConsts.ConnectionStringName)
            );

            return new DgVCoreDbContext(builder.Options);
        }
    }
}