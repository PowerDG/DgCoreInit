﻿using Abp.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace DgVCore.EntityFrameworkCore
{
    public class DgVCoreDbContext : AbpDbContext
    {
        //Add DbSet properties for your entities...

        public DgVCoreDbContext(DbContextOptions<DgVCoreDbContext> options) 
            : base(options)
        {

        }
    }
}
