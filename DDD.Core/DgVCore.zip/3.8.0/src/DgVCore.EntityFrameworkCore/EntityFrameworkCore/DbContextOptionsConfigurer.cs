﻿using Microsoft.EntityFrameworkCore;

namespace DgVCore.EntityFrameworkCore
{
    public static class DbContextOptionsConfigurer
    {
        public static void Configure(
            DbContextOptionsBuilder<DgVCoreDbContext> dbContextOptions, 
            string connectionString
            )
        {
            /* This is the single point to configure DbContextOptions for DgVCoreDbContext */
            dbContextOptions.UseSqlServer(connectionString);
        }
    }
}
