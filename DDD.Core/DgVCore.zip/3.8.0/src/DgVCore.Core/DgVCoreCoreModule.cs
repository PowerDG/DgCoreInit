﻿using Abp.Modules;
using Abp.Reflection.Extensions;
using DgVCore.Localization;

namespace DgVCore
{
    public class DgVCoreCoreModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Auditing.IsEnabledForAnonymousUsers = true;

            DgVCoreLocalizationConfigurer.Configure(Configuration.Localization);
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgVCoreCoreModule).GetAssembly());
        }
    }
}