﻿namespace DgVCore
{
    public class DgVCoreConsts
    {
        public const string LocalizationSourceName = "DgVCore";

        public const string ConnectionStringName = "Default";
    }
}