﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;

namespace DgVCore
{
    [DependsOn(
        typeof(DgVCoreCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class DgVCoreApplicationModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgVCoreApplicationModule).GetAssembly());
        }
    }
}