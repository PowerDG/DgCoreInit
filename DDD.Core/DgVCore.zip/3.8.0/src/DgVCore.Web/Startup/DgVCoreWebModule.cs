﻿using Abp.AspNetCore;
using Abp.AspNetCore.Configuration;
using Abp.Modules;
using Abp.Reflection.Extensions;
using DgVCore.Configuration;
using DgVCore.EntityFrameworkCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace DgVCore.Web.Startup
{
    [DependsOn(
        typeof(DgVCoreApplicationModule), 
        typeof(DgVCoreEntityFrameworkCoreModule), 
        typeof(AbpAspNetCoreModule))]
    public class DgVCoreWebModule : AbpModule
    {
        private readonly IConfigurationRoot _appConfiguration;

        public DgVCoreWebModule(IHostingEnvironment env)
        {
            _appConfiguration = AppConfigurations.Get(env.ContentRootPath, env.EnvironmentName);
        }

        public override void PreInitialize()
        {
            Configuration.DefaultNameOrConnectionString = _appConfiguration.GetConnectionString(DgVCoreConsts.ConnectionStringName);

            Configuration.Navigation.Providers.Add<DgVCoreNavigationProvider>();

            Configuration.Modules.AbpAspNetCore()
                .CreateControllersForAppServices(
                    typeof(DgVCoreApplicationModule).GetAssembly()
                );
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgVCoreWebModule).GetAssembly());
        }
    }
}