namespace DgVCore.Web.Controllers
{
    public class LayoutController : DgVCoreControllerBase
    {

    }
}