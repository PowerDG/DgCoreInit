using Abp.AspNetCore.Mvc.Controllers;

namespace DgVCore.Web.Controllers
{
    public abstract class DgVCoreControllerBase: AbpController
    {
        protected DgVCoreControllerBase()
        {
            LocalizationSourceName = DgVCoreConsts.LocalizationSourceName;
        }
    }
}