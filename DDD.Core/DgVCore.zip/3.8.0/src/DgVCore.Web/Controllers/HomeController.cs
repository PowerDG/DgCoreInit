using Microsoft.AspNetCore.Mvc;

namespace DgVCore.Web.Controllers
{
    public class HomeController : DgVCoreControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }
    }
}