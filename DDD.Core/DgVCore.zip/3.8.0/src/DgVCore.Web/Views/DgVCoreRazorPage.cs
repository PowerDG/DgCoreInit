﻿using Abp.AspNetCore.Mvc.Views;

namespace DgVCore.Web.Views
{
    public abstract class DgVCoreRazorPage<TModel> : AbpRazorPage<TModel>
    {
        protected DgVCoreRazorPage()
        {
            LocalizationSourceName = DgVCoreConsts.LocalizationSourceName;
        }
    }
}
