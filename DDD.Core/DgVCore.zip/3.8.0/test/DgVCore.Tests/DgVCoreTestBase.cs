﻿using System;
using System.Threading.Tasks;
using Abp.TestBase;
using DgVCore.EntityFrameworkCore;
using DgVCore.Tests.TestDatas;

namespace DgVCore.Tests
{
    public class DgVCoreTestBase : AbpIntegratedTestBase<DgVCoreTestModule>
    {
        public DgVCoreTestBase()
        {
            UsingDbContext(context => new TestDataBuilder(context).Build());
        }

        protected virtual void UsingDbContext(Action<DgVCoreDbContext> action)
        {
            using (var context = LocalIocManager.Resolve<DgVCoreDbContext>())
            {
                action(context);
                context.SaveChanges();
            }
        }

        protected virtual T UsingDbContext<T>(Func<DgVCoreDbContext, T> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<DgVCoreDbContext>())
            {
                result = func(context);
                context.SaveChanges();
            }

            return result;
        }

        protected virtual async Task UsingDbContextAsync(Func<DgVCoreDbContext, Task> action)
        {
            using (var context = LocalIocManager.Resolve<DgVCoreDbContext>())
            {
                await action(context);
                await context.SaveChangesAsync(true);
            }
        }

        protected virtual async Task<T> UsingDbContextAsync<T>(Func<DgVCoreDbContext, Task<T>> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<DgVCoreDbContext>())
            {
                result = await func(context);
                context.SaveChanges();
            }

            return result;
        }
    }
}
