using DgVCore.EntityFrameworkCore;

namespace DgVCore.Tests.TestDatas
{
    public class TestDataBuilder
    {
        private readonly DgVCoreDbContext _context;

        public TestDataBuilder(DgVCoreDbContext context)
        {
            _context = context;
        }

        public void Build()
        {
            //create test data here...
        }
    }
}