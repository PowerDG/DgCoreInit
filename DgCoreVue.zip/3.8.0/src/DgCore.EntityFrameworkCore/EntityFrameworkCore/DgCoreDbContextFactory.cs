﻿using DgCore.Configuration;
using DgCore.Web;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace DgCore.EntityFrameworkCore
{
    /* This class is needed to run EF Core PMC commands. Not used anywhere else */
    public class DgCoreDbContextFactory : IDesignTimeDbContextFactory<DgCoreDbContext>
    {
        public DgCoreDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<DgCoreDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            DbContextOptionsConfigurer.Configure(
                builder,
                configuration.GetConnectionString(DgCoreConsts.ConnectionStringName)
            );

            return new DgCoreDbContext(builder.Options);
        }
    }
}