﻿using Abp.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace DgCore.EntityFrameworkCore
{
    public class DgCoreDbContext : AbpDbContext
    {
        //Add DbSet properties for your entities...

        public DgCoreDbContext(DbContextOptions<DgCoreDbContext> options) 
            : base(options)
        {

        }
    }
}
