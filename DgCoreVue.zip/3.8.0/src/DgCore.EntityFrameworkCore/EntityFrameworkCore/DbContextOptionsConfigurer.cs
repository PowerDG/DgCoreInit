﻿using Microsoft.EntityFrameworkCore;

namespace DgCore.EntityFrameworkCore
{
    public static class DbContextOptionsConfigurer
    {
        public static void Configure(
            DbContextOptionsBuilder<DgCoreDbContext> dbContextOptions, 
            string connectionString
            )
        {
            /* This is the single point to configure DbContextOptions for DgCoreDbContext */
            dbContextOptions.UseSqlServer(connectionString);
        }
    }
}
