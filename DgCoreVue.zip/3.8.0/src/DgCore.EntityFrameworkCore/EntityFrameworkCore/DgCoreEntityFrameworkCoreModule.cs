﻿using Abp.EntityFrameworkCore;
using Abp.Modules;
using Abp.Reflection.Extensions;

namespace DgCore.EntityFrameworkCore
{
    [DependsOn(
        typeof(DgCoreCoreModule), 
        typeof(AbpEntityFrameworkCoreModule))]
    public class DgCoreEntityFrameworkCoreModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgCoreEntityFrameworkCoreModule).GetAssembly());
        }
    }
}