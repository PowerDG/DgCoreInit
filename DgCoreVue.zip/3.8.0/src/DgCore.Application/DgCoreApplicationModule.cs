﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;

namespace DgCore
{
    [DependsOn(
        typeof(DgCoreCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class DgCoreApplicationModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgCoreApplicationModule).GetAssembly());
        }
    }
}