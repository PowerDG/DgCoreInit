﻿using Abp.Application.Services;

namespace DgCore
{
    /// <summary>
    /// Derive your application services from this class.
    /// </summary>
    public abstract class DgCoreAppServiceBase : ApplicationService
    {
        protected DgCoreAppServiceBase()
        {
            LocalizationSourceName = DgCoreConsts.LocalizationSourceName;
        }
    }
}