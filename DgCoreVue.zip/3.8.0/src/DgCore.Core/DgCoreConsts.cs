﻿namespace DgCore
{
    public class DgCoreConsts
    {
        public const string LocalizationSourceName = "DgCore";

        public const string ConnectionStringName = "Default";
    }
}