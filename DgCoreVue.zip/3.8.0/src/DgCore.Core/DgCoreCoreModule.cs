﻿using Abp.Modules;
using Abp.Reflection.Extensions;
using DgCore.Localization;

namespace DgCore
{
    public class DgCoreCoreModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Auditing.IsEnabledForAnonymousUsers = true;

            DgCoreLocalizationConfigurer.Configure(Configuration.Localization);
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgCoreCoreModule).GetAssembly());
        }
    }
}