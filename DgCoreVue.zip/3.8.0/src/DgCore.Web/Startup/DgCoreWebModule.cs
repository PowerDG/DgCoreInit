﻿using Abp.AspNetCore;
using Abp.AspNetCore.Configuration;
using Abp.Modules;
using Abp.Reflection.Extensions;
using DgCore.Configuration;
using DgCore.EntityFrameworkCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace DgCore.Web.Startup
{
    [DependsOn(
        typeof(DgCoreApplicationModule), 
        typeof(DgCoreEntityFrameworkCoreModule), 
        typeof(AbpAspNetCoreModule))]
    public class DgCoreWebModule : AbpModule
    {
        private readonly IConfigurationRoot _appConfiguration;

        public DgCoreWebModule(IHostingEnvironment env)
        {
            _appConfiguration = AppConfigurations.Get(env.ContentRootPath, env.EnvironmentName);
        }

        public override void PreInitialize()
        {
            Configuration.DefaultNameOrConnectionString = _appConfiguration.GetConnectionString(DgCoreConsts.ConnectionStringName);

            Configuration.Navigation.Providers.Add<DgCoreNavigationProvider>();

            Configuration.Modules.AbpAspNetCore()
                .CreateControllersForAppServices(
                    typeof(DgCoreApplicationModule).GetAssembly()
                );
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgCoreWebModule).GetAssembly());
        }
    }
}