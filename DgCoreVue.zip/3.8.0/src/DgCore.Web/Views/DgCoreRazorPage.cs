﻿using Abp.AspNetCore.Mvc.Views;

namespace DgCore.Web.Views
{
    public abstract class DgCoreRazorPage<TModel> : AbpRazorPage<TModel>
    {
        protected DgCoreRazorPage()
        {
            LocalizationSourceName = DgCoreConsts.LocalizationSourceName;
        }
    }
}
