using Microsoft.AspNetCore.Mvc;

namespace DgCore.Web.Controllers
{
    public class HomeController : DgCoreControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }
    }
}