namespace DgCore.Web.Controllers
{
    public class LayoutController : DgCoreControllerBase
    {

    }
}