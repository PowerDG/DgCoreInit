using Abp.AspNetCore.Mvc.Controllers;

namespace DgCore.Web.Controllers
{
    public abstract class DgCoreControllerBase: AbpController
    {
        protected DgCoreControllerBase()
        {
            LocalizationSourceName = DgCoreConsts.LocalizationSourceName;
        }
    }
}