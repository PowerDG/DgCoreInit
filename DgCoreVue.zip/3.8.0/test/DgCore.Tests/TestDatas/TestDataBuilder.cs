using DgCore.EntityFrameworkCore;

namespace DgCore.Tests.TestDatas
{
    public class TestDataBuilder
    {
        private readonly DgCoreDbContext _context;

        public TestDataBuilder(DgCoreDbContext context)
        {
            _context = context;
        }

        public void Build()
        {
            //create test data here...
        }
    }
}