﻿using System;
using System.Threading.Tasks;
using Abp.TestBase;
using DgCore.EntityFrameworkCore;
using DgCore.Tests.TestDatas;

namespace DgCore.Tests
{
    public class DgCoreTestBase : AbpIntegratedTestBase<DgCoreTestModule>
    {
        public DgCoreTestBase()
        {
            UsingDbContext(context => new TestDataBuilder(context).Build());
        }

        protected virtual void UsingDbContext(Action<DgCoreDbContext> action)
        {
            using (var context = LocalIocManager.Resolve<DgCoreDbContext>())
            {
                action(context);
                context.SaveChanges();
            }
        }

        protected virtual T UsingDbContext<T>(Func<DgCoreDbContext, T> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<DgCoreDbContext>())
            {
                result = func(context);
                context.SaveChanges();
            }

            return result;
        }

        protected virtual async Task UsingDbContextAsync(Func<DgCoreDbContext, Task> action)
        {
            using (var context = LocalIocManager.Resolve<DgCoreDbContext>())
            {
                await action(context);
                await context.SaveChangesAsync(true);
            }
        }

        protected virtual async Task<T> UsingDbContextAsync<T>(Func<DgCoreDbContext, Task<T>> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<DgCoreDbContext>())
            {
                result = await func(context);
                context.SaveChanges();
            }

            return result;
        }
    }
}
