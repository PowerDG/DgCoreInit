using Abp.AspNetCore.TestBase;
using Abp.Modules;
using Abp.Reflection.Extensions;
using DgCore.Web.Startup;
namespace DgCore.Web.Tests
{
    [DependsOn(
        typeof(DgCoreWebModule),
        typeof(AbpAspNetCoreTestBaseModule)
        )]
    public class DgCoreWebTestModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.UnitOfWork.IsTransactional = false; //EF Core InMemory DB does not support transactions.
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgCoreWebTestModule).GetAssembly());
        }
    }
}